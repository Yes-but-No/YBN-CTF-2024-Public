package dev.czlucius.droidstoolbox

import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import dev.czlucius.droidstoolbox.ui.theme.ToolboxDecryptorTheme
import java.nio.charset.Charset
import java.security.KeyStore
import javax.crypto.Cipher

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ToolboxDecryptorTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    DecryptionMenu(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

fun encDec(text: String, decrypted: Boolean): String {
    if (decrypted) {
        // decrypt
        val keyStore = KeyStore.getInstance("AndroidKeyStore")
        keyStore.load(null)
        var entry = keyStore.getEntry("YBNCTF_TOOLBOX", null)
        val privKey = (entry as KeyStore.PrivateKeyEntry).privateKey
        val cipher = Cipher.getInstance("RSA/ECB/OAEPwithSHA-1andMGF1Padding")
        cipher.init(Cipher.DECRYPT_MODE, privKey)
        val rawEncrypt = Base64.decode(text, Base64.DEFAULT)
        return cipher.doFinal(rawEncrypt).toString(Charset.defaultCharset())

    } else {
        // encrypt
        return text
    }

}



@Composable
fun DecryptionMenu(modifier: Modifier = Modifier) {

    var text by remember { mutableStateOf("") }
    var decrypted by remember { mutableStateOf(false) }
    Column(
        modifier = modifier
    ) {
        Text("Decryption", modifier = Modifier.padding(16.dp))
        TextField(
            value = text,
            onValueChange = { text = it }, // like React's setState
            label = { Text("Enter text to decrypt") },
            modifier = Modifier.padding(16.dp)
        )
        Button(
            onClick = { decrypted = !decrypted },
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Decrypt")
        }
        Text("Decrypted text: ${encDec(text, decrypted)}")
    }

}
