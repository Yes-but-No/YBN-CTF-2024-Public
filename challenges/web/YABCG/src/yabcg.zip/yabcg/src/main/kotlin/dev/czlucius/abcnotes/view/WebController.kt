package dev.czlucius.abcnotes.view

import dev.czlucius.abcnotes.model.BusinessCard
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.ModelAttribute
import org.springframework.web.bind.annotation.PostMapping


@Controller
class WebController {
    @GetMapping("/")
    fun index(model: Model): String {
        return "index"
    }


    @PostMapping("/card")
    fun createCard(@ModelAttribute card: BusinessCard, model: Model): String {
        model.addAttribute("card", card)
        return "card"
    }

    @GetMapping("/card")
    fun getCard(model: Model): String {
        val card = BusinessCard("John Doe", "Acme Inc", "555-555-5555","johndoe@acme.com")
        model.addAttribute("card", card)
        return "card"
    }




}