package dev.czlucius.abcnotes

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class YabcgApp

fun main(args: Array<String>) {
//    DB
    runApplication<YabcgApp>(*args)
}
