package dev.czlucius.abcnotes.model

data class BusinessCard(
    val name: String,
    val company: String,
    val phoneNumber: String,
    val email: String,
)