package dev.czlucius.abcnotes;

import com.fasterxml.jackson.core.Base64Variant;
import com.fasterxml.jackson.core.util.ByteArrayBuilder;
import com.fasterxml.jackson.databind.ser.Serializers;
import io.netty.handler.codec.base64.Base64Decoder;
import kotlin.io.LineReader;
import kotlin.io.encoding.Base64JVMKt;
import kotlin.io.encoding.Base64Kt;
import kotlin.text.Charsets;
import kotlin.text.HexFormat;
import kotlin.text.StringsKt;
import kotlinx.serialization.internal.ByteArraySerializer;
import kotlinx.serialization.json.internal.CharsetReader;
import org.apache.logging.log4j.util.Base64Util;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.propertyeditors.CharsetEditor;
import org.springframework.core.env.Environment;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.FileSystemResourceLoader;
import org.springframework.core.io.ResourceLoader;
import org.springframework.security.crypto.keygen.Base64StringKeyGenerator;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;

public class a {
//    public static void main(String[] args) throws IOException, ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
//        kotlin.io.FilesKt.readBytes(null);
////        Class a = kotlin.reflect.full.KClasses.createInstance("")
////        kotlin.system.ProcessKt
////        Class a = Class.forName("kotlinx.")
//        System.out.println("Hello, World!");
////        kotlin.io.FilesKt.readBytes()
//        ResourceLoader rl = new org.springframework.core.io.FileSystemResourceLoader();
//        rl.getResource("file:/home/czlucius/abcnotes/src/main/kotlin/dev/czlucius/abcnotes/a.java");
////        new FileSystemResource("/tmp/aaa.txt").
////        "A".getClass().getDeclaredConstructor()
////        ArrayList<String> a = new ArrayList<>(
////        LineReader.INSTANCE.readLine(
//        new FileSystemResource("/tmp/aaa.txt").getContentAsByteArray();
////        new String(
//
////        kotlin.io.TextStreamsKt.
////        new kotlin.collections.
////        org.springframework.util.StringUtils.
////        Base64Decoder d = new Base64();
////        String.copyB
//
//        new FileSystemResourceLoader().getResource("/").getContentAsByteArray()
//                ;
//        org.springframework.core.env.Environment e = new org.springframework.core.env.StandardEnvironment();
//        StandardEnvironment se = new StandardEnvironment();
//        e.getActiveProfiles()
//        byte []ba = new byte[10];
////        kotlin.reflect.full.KClasses.
////        Charsets.UTF_8.decode(ba)
//        kotlin.io.FilesKt.readText(new FileSystemResourceLoader().getResource("dn").getFile(), null);
//Clas
//
//        kotlin.text.StringsKt.class.getMethod("toByteArray", String.class, Charset.class).invoke(null, "a", Charset.defaultCharset());
//
//        "b".getClass().forName("org.springframework.core.io.FileSystemResource"))
////        "a".getClass().getDeclaredConstructor()
//        new String();
//        "a".getClass().getDeclaredConstructor();
////        Byte[] a = new Byte[10];
////        new String(a.);
//        byte[].class;
////        Charact
//        String AA = 91 + "a";
//        byte[] a = new byte[10];
//
////        java.util.Arrays
////        Arrays.toString()
//
//        Object aaa2 = (Class.forName("java.util.Arrays")).getMethod("toString", byte[].class).invoke(null,);
////        "".getClass().getDeclaredConstructor(a.getClass())
////        String
////        java.io.File
//    }
}
