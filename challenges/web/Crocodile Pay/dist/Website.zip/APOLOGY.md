To whoever attempts to solve this challenge
I'm sorry you have to read whatever this code is in advance

Your's truly,
Baba.



When I created this code, only god and I knew what it was doing
Now, only god knows.