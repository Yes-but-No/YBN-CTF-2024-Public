// next.config.js
module.exports = {
    eslint: {
        // This is probably not relevant to the challenge. I just did this cause im lazy
        // pls spare me its 2.30am
        ignoreDuringBuilds: true,
    }
};
