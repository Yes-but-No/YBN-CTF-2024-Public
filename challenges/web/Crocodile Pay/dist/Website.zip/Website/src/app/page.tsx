export { default } from "./(pages)/home/page";
